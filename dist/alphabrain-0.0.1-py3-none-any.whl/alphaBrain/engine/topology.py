"""This module is deprecated, but kept around for backwards compatibility.
"""
from .base_layer import Layer, Node, InputSpec
from .input_layer import Input, InputLayer
from .network import Network, get_source_inputs
